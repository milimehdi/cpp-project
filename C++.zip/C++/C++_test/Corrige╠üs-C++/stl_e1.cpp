// stl_e1.cpp

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iterator>
#include <map>
#include <algorithm>
using namespace std;

class Personne
{
public :
	Personne(const string& nomPers, int agePers) : nom(nomPers)
        { age = agePers; }
	void afficher() const { cout << nom << " " << age << endl; }
	string getNom() const { return nom; }
	int getAge() const { return age; }

private :
	string nom;
	int age;
};

vector<Personne> vectPers;
map<string, Personne> mapPers;

void lire_fichier() {
    ifstream flux("fic1.txt");
    bool continuer  = true;
	while (continuer) {
		string nom;
        int age;
        flux >> nom >> age;
        if (flux.eof())
            continuer = false;
		else {
			Personne pers(nom, age);
			vectPers.push_back(pers);
			
			pair<string, Personne> elemMap(nom, pers);
			pair<map<string, Personne>::iterator, bool> cr;
			cr = mapPers.insert(elemMap);
			if (cr.second == false)
				cout << elemMap.first << " deja present" << endl;
		}
    }
}

void tester_vector() {
	cout << "AFFICHER PAR INDICE :" << endl;
	for (int i = 0; i < (int)vectPers.size(); i++)
		vectPers.at(i).afficher();

	cout << "AFFICHER PAR ITERATEUR :" << endl;
	vector<Personne>::iterator it;
	for (it = vectPers.begin(); it != vectPers.end(); it++)
		it->afficher();
}

void tester_map() {
	cout << "AFFICHER MAP :" << endl;
	map<string, Personne>::iterator it;
	for (it = mapPers.begin(); it != mapPers.end(); it++)
		it->second.afficher();
}

class ComparePersParAge
{
public :
	bool operator()(const Personne& pers1, const Personne& pers2) {
		return pers1.getAge() < pers2.getAge();
	}
};

class ComparePersParNom
{
public :
	bool operator()(const Personne& pers1, const Personne& pers2) {
		return pers1.getNom() < pers2.getNom();
	}
};

void tester_algo() {
	cout << "TRI AGE :" << endl;
	sort(vectPers.begin(), vectPers.end(), ComparePersParAge());
	
	for (unsigned int i = 0; i <vectPers.size(); i++)
		vectPers[i].afficher();

	cout << "TRI NOM :" << endl;
	sort(vectPers.begin(), vectPers.end(), ComparePersParNom());

	for (unsigned int i = 0; i < vectPers.size(); i++)
		vectPers[i].afficher();
}

int main ()
{
	lire_fichier();
	tester_vector();
	tester_map();
	tester_algo();

    return 0;
}
