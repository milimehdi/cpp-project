// stl_e2.cpp

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
using namespace std;

vector<string> mots;

void lire_fichier() {
    ifstream flux("fic2.txt");
    bool continuer  = true;
    while (continuer) {
		string un_mot;
        flux >> un_mot;
        if (flux.eof())
            continuer = false;
		else 
			mots.push_back(un_mot);
    }
}

class Affichage
{
public :
	Affichage(bool retour) { retourLigne = retour; }

	void operator()(const string& s) {
		cout << s;
		if (retourLigne)
			cout << endl;
		else
			cout << " ";
	}

private :
	bool retourLigne;
};

class CompareLg
{
public :
	bool operator()(const string& s1, const string& s2) {
		return s1.size() < s2.length();
	}
};

class LgInferieureA
{
public :
	LgInferieureA(int la_lg) { lg = la_lg; }

	bool operator()(const string& s) {
		return (int)s.length() < lg;
	}
private :
	int lg;
};

int main ()
{
	lire_fichier();
	
    cout << "AFFICHAGE VECTEUR :" << endl;
	for (vector<string>::iterator it = mots.begin(); it != mots.end(); it++)
		cout << (*it) << endl;

	cout << "AFFICHAGE FOR_EACH :" << endl;
	for_each(mots.begin(), mots.end(), Affichage(true));
	for_each(mots.begin(), mots.end(), Affichage(false));
    cout << endl;

    cout << "TRI SIMPLE (ALPHABETIQUE) :" << endl;
	sort(mots.begin(), mots.end());
	for_each(mots.begin(), mots.end(), Affichage(true));

    cout << "TRI PAR LONGUEUR :" << endl;
	sort(mots.begin(), mots.end(), CompareLg());
	for_each(mots.begin(), mots.end(), Affichage(true));

	cout << "nb de comment = " << count(mots.begin(), mots.end(), "comment") << endl;
	cout << "nb lg < 5 = " << count_if(mots.begin(), mots.end(), LgInferieureA(5)) << endl;
	
	vector<string>::iterator it = find_if(mots.begin(), mots.end(), LgInferieureA(5));
	if (it != mots.end())
		cout << "1er de lg < 5 : " << *it << endl;

	return 0;
}
 
