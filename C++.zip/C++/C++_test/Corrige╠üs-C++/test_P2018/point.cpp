// point.cpp

#include <iostream>
#include <math.h>
#include "radian.h"
#include "point.h"
using namespace std;

Point::Point()
  : theta(0)
{
    r = 0;
}

Point::Point(double ray, const Radian& the)
  : theta(the)
{
    r = ray;
}

Point::Point(double x, double y)
  : theta(atan2(y, x))
{
    r = sqrt(x * x + y * y);
}

double Point::getR() const
{
    return r;
}

Radian Point::getTheta() const
{
    return theta;
}

void Point::setPol(double ray, const Radian& the)
{
    r = ray;
    theta = the; // ou theta.setAngle(the.getAngle());
}

double Point::getx() const
{
    return r * cos(theta.getAngle());
}

double Point::gety() const
{
    return r * sin(theta.getAngle());
}

void Point::setCart(double x, double y)
{
    r = sqrt(x * x + y * y);
    theta.setAngle(atan2(y, x));
}

void Point::afficherPol() const
{
    cout << "(r=" << r << ", theta=" << theta << ")" << endl;
}

void Point::afficherCart() const
{
    cout << "(x=" << getx() << ", y=" << gety() << ")" << endl;
}
