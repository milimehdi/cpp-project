// polygone.cpp

#include <iostream>
#include <math.h>
#include "point2.h"
#include "polygone.h"
using namespace std;

Polygone::Polygone(const Point2* tabPoints, int ord)
{
    allouerEtCopier(tabPoints, ord);
}

Polygone::Polygone(const Polygone& poly2)
{
    allouerEtCopier(poly2.sommets, poly2.ordre);
}

Polygone::~Polygone()
{
    delete [] sommets;
}

Polygone& Polygone::operator=(const Polygone& poly2)
{
    if (&poly2 != this)
      allouerEtCopier(poly2.sommets, poly2.ordre);
    return *this;
}

void Polygone::afficher() const
{
    for(int i = 0; i < ordre; i++)
        sommets[i].afficherCart();
}

double Polygone::perimetre() const
{
    double peri = 0;

    for(int i = 0; i < ordre - 1; i++)
        peri += sommets[i].distance(sommets[i + 1]);
    peri += sommets[ordre - 1].distance(sommets[0]);

    return peri;
}

void Polygone::allouerEtCopier(const Point2* tabPoints, int ord)
{
    sommets = new Point2[ord];
    for (int i = 0; i < ord; i++)
      sommets[i] = tabPoints[i];
    ordre = ord;
}
