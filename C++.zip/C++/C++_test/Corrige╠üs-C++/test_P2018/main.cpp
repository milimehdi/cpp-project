// main.cpp

#include <iostream>
#include <math.h>
#include "radian.h"
#include "point.h"
#include "point2.h"
#include "polygone.h"
using namespace std;

void testerRadian();
void testerPoint();
void testerPoint2();
void testerPolygone();

void testerRadian()
{
    Radian r0, r1(0.5 * M_PI), r2(4.5 * M_PI), r3(5.5 * M_PI);
    Radian r4(-0.5 * M_PI), r5(-4.5 * M_PI), r6(-5.5 * M_PI); 
    cout << r0 << ", " << r1 << ", " << r2 << ", " << r3 << endl;
    cout << r4 << ", " << r5 << ", " << r6 << endl;

    r0.setAngle(1.5 * M_PI);
    cout << r0.getAngle() << endl;

    cout << "saisir un angle : ";
    cin >> r0;
    cout << r0 << endl;

    Radian r7(2), r8(3);
    cout << r7 + r8 << ", " << 1.5 * r7 << ", " << r7 * 2.5 << endl;
    cout << r1.toDegree() << " " << Radian::createFromDegree(200) << endl;
}

void testerPoint()
{
    Radian t1(0.33 * M_PI);
    Point P0, P1(2, t1), P2(2, 1);
    P0.afficherPol();
    P0.afficherCart();
    P1.afficherPol();
    P1.afficherCart();
    P2.afficherPol();
    P2.afficherCart();
    P2.setCart(2,4);
    P2.afficherPol();
}

void testerPoint2()
{
    Radian t1(0.33 * M_PI), t2(0.5 * M_PI);
    Point2 P1(2, t1);
    P1.homothetie(1.5);
    P1.afficherPol();
    P1.rotation(t2);
    P1.afficherPol();
    Point2 P2 = P1;
    P2.homothetie(2.5);
    cout << P1.distance(P2) << endl;
}

void testerPolygone()
{
    Point2 tp[] = { Point2(1,2), Point2(2,4), Point2(5,5), Point2(6,2),
                    Point2(5,-5), Point2(-1,-3) };
    Polygone pol(tp, 6);
    pol.afficher();
    cout << pol.perimetre() << endl;
}

int main()
{
    //testerRadian();
    //testerPoint();
    //testerPoint2();
    testerPolygone();

    return 0;
}
