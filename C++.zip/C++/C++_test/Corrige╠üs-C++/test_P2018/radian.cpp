// radian.cpp

#include <iostream>
#include <math.h>
#include "radian.h"
using namespace std;

Radian::Radian()
{
    angle = 0;
}

Radian::Radian(double ang)
{
    angle = ang;
    normaliser();
}

double Radian::getAngle() const
{
    return angle;
}

void Radian::setAngle(double ang)
{
    angle = ang;
    normaliser();
}

ostream& operator<<(ostream& flux, const Radian& rad)
{
    flux << rad.angle << " rad";
    return flux;
}

istream& operator>>(istream& flux, Radian& rad)
{
    flux >> rad.angle;
    rad.normaliser();
    return flux;
}

// pour les operateurs la normalisation de l'angle est automatique puisqu'on
// appelle le constructeur pour l'objet resultat

Radian Radian::operator+(const Radian& rad2) const
{
    Radian result(angle + rad2.angle);
    return result;
}

Radian operator*(double a, const Radian& rad)
{
    Radian result(a * rad.angle);
    return result;
}

Radian Radian::operator*(double a) const
{
    Radian result(angle * a);
    return result;
}

double Radian::toDegree() const
{
    return (angle * 180) / M_PI;
}

Radian Radian::createFromDegree(double deg)
{
    Radian rad((deg * M_PI) / 180);
    return rad;
}

void Radian::normaliser()
{
    angle = fmod(angle, 2*M_PI);
    if (angle > M_PI)
        angle -= 2*M_PI;
    else if (angle < -M_PI)
        angle += 2*M_PI;
}
