// point.h

#pragma once

#include <iostream>
#include "radian.h"
using namespace std;

class Point
{
public :
    Point();
    Point(double ray, const Radian& the);
    Point(double x, double y);
    double getR() const;
    Radian getTheta() const;
    void setPol(double ray, const Radian& the);
    double getx() const;
    double gety() const;
    void setCart(double x, double y);
    void afficherPol() const;
    void afficherCart() const;

private :
    double r;
    Radian theta;
};
