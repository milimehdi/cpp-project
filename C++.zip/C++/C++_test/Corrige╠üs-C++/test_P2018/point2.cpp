// point2.cpp

#include <iostream>
#include <math.h>
#include "radian.h"
#include "point.h"
#include "point2.h"
using namespace std;

Point2::Point2()
  : Point()
{
}

Point2::Point2(double ray, const Radian& the)
  : Point(ray, the)
{
}

Point2::Point2(double x, double y)
  : Point(x, y)
{
}

void Point2::homothetie(double k)
{
    // en toute rigueur il faudrait tenir compte du cas k < 0
    setPol(k * getR(), getTheta());
}

void Point2::rotation(const Radian& rad)
{
    setPol(getR(), getTheta() + rad);
}

double Point2::distance(const Point2& P2) const
{
    double dx = P2.getx() - getx();
    double dy = P2.gety() - gety();
    return sqrt(dx * dx + dy * dy);
}
