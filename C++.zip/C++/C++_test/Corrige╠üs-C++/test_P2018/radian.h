// radian.h 

#pragma once

#include <iostream>
using namespace std;

class Radian
{
public :
    Radian();
    Radian(double ang);
    double getAngle() const;
    void setAngle(double ang);
    friend ostream& operator<<(ostream& flux, const Radian& rad);
    friend istream& operator>>(istream& flux, Radian& rad);
    Radian operator+(const Radian& rad2) const;
    friend Radian operator*(double a, const Radian& rad); // reel * Radian
    Radian operator*(double a) const; // Radian * reel
    double toDegree() const;
    static Radian createFromDegree(double deg);

private :
    double angle;

    // reduit la valeur de l'angle à la plage [-PI,+PI]
    void normaliser();
};
