// point2.h

#pragma once

#include <iostream>
#include <math.h>
#include "radian.h"
#include "point.h"
using namespace std;

class Point2 : public Point
{
public :
    Point2();
    Point2(double ray, const Radian& the);
    Point2(double x, double y);
    void homothetie(double k);
    void rotation(const Radian& rad);
    double distance(const Point2& P2) const;

private :
};
