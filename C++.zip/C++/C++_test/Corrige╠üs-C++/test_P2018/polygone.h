// polygone.h

#pragma once

#include <iostream>
#include <math.h>
#include "point2.h"
using namespace std;

class Polygone
{
public :
    Polygone(const Point2* tabPoints, int ord);

    // 4b : il faut ecrire le destructeur, le constructeur par copie et
    // l'operateur =
    Polygone(const Polygone& poly2);
    ~Polygone();
    Polygone& operator=(const Polygone& poly2);

    void afficher() const;
    double perimetre() const;

private :
    Point2* sommets;
    int ordre;

    void allouerEtCopier(const Point2* tabPoints, int ord);
};
