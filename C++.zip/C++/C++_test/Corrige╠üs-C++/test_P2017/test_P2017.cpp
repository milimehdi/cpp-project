// test_P2017.cpp

/* bareme detaille
1.a	1,5
1.b	1
1.c	1,5
1.d	0,5
1.e	1,5

2.a	1
2.b	1
2.c	2

3.a	2
3.b	1
3.c	1

4.a	constructeurs 1,5, operateur<< 0,5
4.b	chaque operateur 1, -0,5 par operateur inutile
*/

#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

class Array
{
public :
    Array(int theSize);
    void load(const int* tab);
    friend ostream& operator<<(ostream& flux, const Array& arr);

    ~Array();
    Array(const Array& arr2);
    Array& operator=(const Array& arr2);

    bool operator==(const Array& arr2) const;

    int get(int i) const        { return elem[i]; }
    void set(int i, int val)    { elem[i] = val; }
    int size() const            { return taille; }

    void resize(int newSize);

private :
    int* elem;
    int taille;

    void createFromArray(const Array& arr2);
};

Array::Array(int theSize)
{
    elem = new int[theSize];
    taille = theSize;
    for (int i = 0; i < theSize; i++)
        elem[i] = 0;
}

void Array::load(const int* tab)
{
    for (int i = 0; i < taille; i++)
        elem[i] = tab[i];
}

ostream& operator<<(ostream& flux, const Array& arr)
{
    flux << "[";
    for (int i = 0; i < arr.taille; i++) {
        flux << arr.elem[i];
        if (i < arr.taille - 1)
            cout << " ";
    }
    flux << "]";
	return flux;
}

/* 1.b : la classe alloue dynamiquement le tableau, il faut donc ajouter le
destructeur, le constructeur par copie et l'operateur =
*/
// destructeur
Array::~Array()
{
    delete [] elem;
}

// constructeur par copie
Array::Array(const Array& arr2)
{
    createFromArray(arr2);
}

Array& Array::operator=(const Array& arr2)
{
    if (this != &arr2) {
        delete [] elem;
        createFromArray(arr2);
    }
	return *this;
}

bool Array::operator==(const Array& arr2) const
{
    if (taille != arr2.taille)
        return false;

    for (int i = 0; i < taille; i++)
            if (elem[i] != arr2.elem[i])
                return false ;
    return true;
}

void Array::resize(int newSize)
{
    if (newSize != taille) {
        int* newElem = new int[newSize];

        if (newSize > taille) {
            for (int i = 0; i < taille; i++)
                newElem[i] = elem[i];
            for (int i = taille; i < newSize; i++)
                newElem[i] = 0;
        }
        else
            for (int i = 0; i < newSize; i++)
                newElem[i] = elem[i];

        delete [] elem;
        elem = newElem;
        taille = newSize;
    }
}

void Array::createFromArray(const Array& arr2)
{
    elem = new int[arr2.taille];
    taille = arr2.taille;
    load(arr2.elem);
}

class ArraySec : public Array
{
public :
    ArraySec(int theSize);
    int indexOf(int val) const;
    ArraySec subArray (int begin, int end) const;
    int get(int i) const;
    void set(int i, int val);
    void resize(int newSize);
};

void paramError(const char* msg, int invalidParam)
{
	cout << msg << " " << invalidParam << endl;
	exit(0);
}

/* 2.a
ArraySec::ArraySec(int theSize)
    : Array(theSize)
{
}
*/
// 3.b
ArraySec::ArraySec(int theSize)
    : Array(1)      // pour eviter de faire Array(theSize) si theSize est <= 0
{
    if (theSize <= 0)
        paramError("constructeur : taille incorrecte", theSize);
    resize(theSize);
}

int ArraySec::indexOf(int val) const
{
    int i = 0;
    while (get(i) != val && i < size())
        i++;
    if (i < size())
        return i;
    else
        return -1;
}

/* 2.c
cette fonction extrait le sous-tableau [begin, end], on aurait pu choisir
[begin, end[
ArraySec ArraySec::subArray (int begin, int end) const
{
	ArraySec subArr(end - begin + 1);
    for (int i = begin; i <= end; i++)
        subArr.set(i - begin, get(i));
    return subArr;
}
*/
// 3.b
ArraySec ArraySec::subArray (int begin, int end) const
{
	if (begin < 0 || begin >= size())
		paramError("subArray : indice debut incorrect", begin);
	if (end < 0 || end >= size())
		paramError("subArray : indice fin incorrect", end);
    if (begin > end)
		paramError("subArray : ordre des indices incorrect", begin - end);
    
	ArraySec subArr(end - begin + 1);
    for (int i = begin; i <= end; i++)
        subArr.set(i - begin, get(i));
    return subArr;
}

// 3.a
int ArraySec::get(int i) const
{
    if (i < 0 || i >= size())
        paramError("get : indice incorrect", i);
    return Array::get(i);
}

// 3.a
void ArraySec::set(int i, int val)
{
    if (i < 0 || i >= size())
        paramError("set : indice incorrect", i);
    Array::set(i, val);
}

// 3.a
void ArraySec::resize(int newSize)
{
    if (newSize <= 0)
        paramError("resize : taille incorrecte", newSize);
    Array::resize(newSize);
}

/* 3.c
lorsqu'on fait parr->get(ind), le pointeur est de type Array*, c'est donc la
fonction get de Array qui est appelee meme si l'objet est de type ArraySec;
l'appel n'est donc pas securise;
pour que ce soit la fonction get de ArraySec qui soit appelee il faut declarer
get virtual au niveau de Array;
idem pour set et resize
*/

class Vect : public vector<int>
{
public :
    Vect(int theSize);
    Vect(int theSize, const int* tab);
    friend ostream& operator<<(ostream& flux, const Vect& v);
    Vect operator+(const Vect& v2) const;
    friend Vect operator*(int scal, const Vect& v2);
    Vect operator*(int scal) const;
    int operator*(const Vect& v2) const;
};

// constructeurs de Vect : ils appellent le constructeur de la classe
// vector<int> qui cree un vecteur vide, puis par ajout d'elements par
// push_back les vecteurs prennent la taille demandee

Vect::Vect(int theSize)
    : vector<int>()
{
    for (int i= 0; i < theSize; i++)
        push_back(0);
}

Vect::Vect(int theSize, const int* tab)
    : vector<int>()
{
    for (int i= 0; i < theSize; i++)
        push_back(tab[i]);
}

ostream& operator<<(ostream& flux, const Vect& v)
{
    flux << "(";
    for (int i = 0; i < v.size(); i++) {
        flux << v.at(i);
        if (i < v.size() - 1)
            flux << " ";
    }
    flux << ")";
    return flux;
}

// un vecteur + un vecteur
Vect Vect::operator+(const Vect& v2) const
{
    Vect vectResult(size());

    for (int i = 0; i < size(); i++)
        vectResult.at(i) = at(i) + v2.at(i);

    return vectResult;
}

// un scalaire * un vecteur, comme dans 2 * v2;
// ce doit etre une fonction amie car le 1er operande n'est pas un vecteur
Vect operator*(int scal, const Vect& v)
{
    Vect vectResult(v.size());

    for (int i = 0; i < v.size(); i++)
        vectResult.at(i) = scal * v.at(i);

    return vectResult;
}

// un vecteur * un scalaire, comme dans v1 * 3
Vect Vect::operator*(int scal) const
{
    // appel de l'autre operateur * : le scalaire * l'objet courant
	return scal * (*this);
}

// un vecteur * un vecteur (produit scalaire)
int Vect::operator*(const Vect& v2) const
{
    int result = 0;

    for (int i = 0; i < size(); i++)
        result += at(i) * v2.at(i);

    return result;
}

void f(Array* parr)
{
	int ind;
	cout << "saisir un indice : ";
	cin >> ind;
	cout << parr->get(ind) << endl;
}

void testerArray()
{
    int t1[] = {4, 2, 5, 0, 8, 7, 6, 12, 9, 2};
    Array a1(10);
	cout << a1 << endl;
    a1.load(t1);
    cout << a1 << endl;
    Array a2 = a1;
    a2.set(2, 4);
    Array a3(10);
    a3 = a1;
    a3.set(3, 6);
    cout << a1 << " " << a2 << " " << a3 << endl;
    a2.set(2, 5);
    if (a1 == a2 && !(a1 == a3))
        cout << "operateur == ok" << endl;
    a2.resize(5);
    a3.resize(15);
	cout << a2 << " " << a3 << endl;

	ArraySec a4(10);
	cout << a4 << endl;
	a4.load(t1);
	cout << a4 << endl;
	cout << a4.indexOf(2) << endl;
	ArraySec a5 = a4.subArray(3, 6);
	cout << a5 << endl;
	cout << a5.get(2) << endl;
	a5.set(2, 11);
	a5.resize(10);
	cout << a5 << endl;
	f(&a5);
}

void testerVect()
{
	Vect v(10);
	cout << v << endl;
	int t1[] = {2, 3, 2, 4, 5};
	Vect v1(5, t1);
	cout << v1 << endl;
	int t2[] = {4, 2, 1, 3, 2};
	Vect v2(5, t2);
	cout << v2 << endl;
	Vect v3 = v1 + v2 + 2 * v2 + v1 * 3;
	cout << v3 << endl;
	cout << v1 * v2 << endl;
}

int main()
{
	testerArray();
	testerVect();
    return 0;
}
