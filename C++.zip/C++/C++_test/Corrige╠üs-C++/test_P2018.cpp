// test_P2018.cpp
// bareme : 1a(1) 1b(0,5) 1c(1,5) 1d(2) 1e(1,5) 2a(0,5) 2b(0,5) 2c(1,5) 2d(1)
//          3a(1,5) 3b(1) 3c(1,5) 3d(1) 4a(1) 4b(1,5) 4c(1) 4d(1,5)

#include <iostream>
#include <math.h>
using namespace std;

class Radian
{
public :
    Radian();
    Radian(double ang);
    double getAngle() const;
    void setAngle(double ang);
    friend ostream& operator<<(ostream& flux, const Radian& rad);
    friend istream& operator>>(istream& flux, Radian& rad);
    Radian operator+(const Radian& rad2) const;
    friend Radian operator*(double a, const Radian& rad); // reel * Radian
    Radian operator*(double a) const; // Radian * reel
    double toDegree() const;
    static Radian createFromDegree(double deg);

private :
    double angle;

    // reduit la valeur de l'angle à la plage [-PI,+PI]
    void normaliser();
};

Radian::Radian()
{
    angle = 0;
}

Radian::Radian(double ang)
{
    angle = ang;
    normaliser();
}

double Radian::getAngle() const
{
    return angle;
}

void Radian::setAngle(double ang)
{
    angle = ang;
    normaliser();
}

ostream& operator<<(ostream& flux, const Radian& rad)
{
    flux << rad.angle << " rad";
    return flux;
}

istream& operator>>(istream& flux, Radian& rad)
{
    flux >> rad.angle;
    rad.normaliser();
    return flux;
}

// pour les operateurs la normalisation de l'angle est automatique puisqu'on
// appelle le constructeur pour l'objet resultat

Radian Radian::operator+(const Radian& rad2) const
{
    Radian result(angle + rad2.angle);
    return result;
}

Radian operator*(double a, const Radian& rad)
{
    Radian result(a * rad.angle);
    return result;
}

Radian Radian::operator*(double a) const
{
    Radian result(angle * a);
    return result;
}

double Radian::toDegree() const
{
    return (angle * 180) / M_PI;
}

Radian Radian::createFromDegree(double deg)
{
    Radian rad((deg * M_PI) / 180);
    return rad;
}

void Radian::normaliser()
{
    angle = fmod(angle, 2*M_PI);
    if (angle > M_PI)
        angle -= 2*M_PI;
    else if (angle < -M_PI)
        angle += 2*M_PI;
}

class Point
{
public :
    Point();
    Point(double ray, const Radian& the);
    Point(double x, double y);
    double getR() const;
    Radian getTheta() const;
    void setPol(double ray, const Radian& the);
    double getx() const;
    double gety() const;
    void setCart(double x, double y);
    void afficherPol() const;
    void afficherCart() const;

private :
    double r;
    Radian theta;
};

Point::Point()
  : theta(0)
{
    r = 0;
}

Point::Point(double ray, const Radian& the)
  : theta(the)
{
    r = ray;
}

Point::Point(double x, double y)
  : theta(atan2(y, x))
{
    r = sqrt(x * x + y * y);
}

double Point::getR() const
{
    return r;
}

Radian Point::getTheta() const
{
    return theta;
}

void Point::setPol(double ray, const Radian& the)
{
    r = ray;
    theta = the; // ou theta.setAngle(the.getAngle());
}

double Point::getx() const
{
    return r * cos(theta.getAngle());
}

double Point::gety() const
{
    return r * sin(theta.getAngle());
}

void Point::setCart(double x, double y)
{
    r = sqrt(x * x + y * y);
    theta.setAngle(atan2(y, x));
}

void Point::afficherPol() const
{
    cout << "(r=" << r << ", theta=" << theta << ")" << endl;
}

void Point::afficherCart() const
{
    cout << "(x=" << getx() << ", y=" << gety() << ")" << endl;
}

class Point2 : public Point
{
public :
    Point2();
    Point2(double ray, const Radian& the);
    Point2(double x, double y);
    void homothetie(double k);
    void rotation(const Radian& rad);
    double distance(const Point2& P2) const;

private :
};

Point2::Point2()
  : Point()
{
}

Point2::Point2(double ray, const Radian& the)
  : Point(ray, the)
{
}

Point2::Point2(double x, double y)
  : Point(x, y)
{
}

void Point2::homothetie(double k)
{
    // en toute rigueur il faudrait tenir compte du cas k < 0
    setPol(k * getR(), getTheta());
}

void Point2::rotation(const Radian& rad)
{
    setPol(getR(), getTheta() + rad);
}

double Point2::distance(const Point2& P2) const
{
    double dx = P2.getx() - getx();
    double dy = P2.gety() - gety();
    return sqrt(dx * dx + dy * dy);
}

class Polygone
{
public :
    Polygone(const Point2* tabPoints, int ord);

    // 4b : il faut ecrire le destructeur, le constructeur par copie et
    // l'operateur =
    Polygone(const Polygone& poly2);
    ~Polygone();
    Polygone& operator=(const Polygone& poly2);

    void afficher() const;
    double perimetre() const;

private :
    Point2* sommets;
    int ordre;

    void allouerEtCopier(const Point2* tabPoints, int ord);
};

Polygone::Polygone(const Point2* tabPoints, int ord)
{
    allouerEtCopier(tabPoints, ord);
}

Polygone::Polygone(const Polygone& poly2)
{
    allouerEtCopier(poly2.sommets, poly2.ordre);
}

Polygone::~Polygone()
{
    delete [] sommets;
}

Polygone& Polygone::operator=(const Polygone& poly2)
{
    if (&poly2 != this)
      allouerEtCopier(poly2.sommets, poly2.ordre);
    return *this;
}

void Polygone::afficher() const
{
    for(int i = 0; i < ordre; i++)
        sommets[i].afficherCart();
}

double Polygone::perimetre() const
{
    double peri = 0;

    for(int i = 0; i < ordre - 1; i++)
        peri += sommets[i].distance(sommets[i + 1]);
    peri += sommets[ordre - 1].distance(sommets[0]);

    return peri;
}

void Polygone::allouerEtCopier(const Point2* tabPoints, int ord)
{
    sommets = new Point2[ord];
    for (int i = 0; i < ord; i++)
      sommets[i] = tabPoints[i];
    ordre = ord;
}

void testerRadian()
{
    Radian r0, r1(0.5 * M_PI), r2(4.5 * M_PI), r3(5.5 * M_PI);
    Radian r4(-0.5 * M_PI), r5(-4.5 * M_PI), r6(-5.5 * M_PI); 
    cout << r0 << ", " << r1 << ", " << r2 << ", " << r3 << endl;
    cout << r4 << ", " << r5 << ", " << r6 << endl;

    r0.setAngle(1.5 * M_PI);
    cout << r0.getAngle() << endl;

    cout << "saisir un angle : ";
    cin >> r0;
    cout << r0 << endl;

    Radian r7(2), r8(3);
    cout << r7 + r8 << ", " << 1.5 * r7 << ", " << r7 * 2.5 << endl;
    cout << r1.toDegree() << " " << Radian::createFromDegree(200) << endl;
}

void testerPoint()
{
    Radian t1(0.33 * M_PI);
    Point P0, P1(2, t1), P2(2, 1);
    P0.afficherPol();
    P0.afficherCart();
    P1.afficherPol();
    P1.afficherCart();
    P2.afficherPol();
    P2.afficherCart();
    P2.setCart(2,4);
    P2.afficherPol();
}

void testerPoint2()
{
    Radian t1(0.33 * M_PI), t2(0.5 * M_PI);
    Point2 P1(2, t1);
    P1.homothetie(1.5);
    P1.afficherPol();
    P1.rotation(t2);
    P1.afficherPol();
    Point2 P2 = P1;
    P2.homothetie(2.5);
    cout << P1.distance(P2) << endl;
}

void testerPolygone()
{
    Point2 tp[] = { Point2(1,2), Point2(2,4), Point2(5,5), Point2(6,2),
                    Point2(5,-5), Point2(-1,-3) };
    Polygone pol(tp, 6);
    pol.afficher();
    cout << pol.perimetre() << endl;
}

int main()
{
    //testerRadian();
    //testerPoint();
    //testerPoint2();
    testerPolygone();

    return 0;
}
